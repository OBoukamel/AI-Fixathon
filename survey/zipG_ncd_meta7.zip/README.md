# Primary Care: NCD Screening (BP + Glucose)

Synthetic health survey package (fake data).

- form/ncd_screening.xlsx  (XLSForm for Kobo/ODK)
- data/submissions.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
