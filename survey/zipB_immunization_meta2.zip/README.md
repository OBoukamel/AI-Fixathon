# Child Health: Immunization Visit (0–24 months)

Synthetic health survey package (fake data).

- form/ch_immunization_visit.xlsx  (XLSForm for Kobo/ODK)
- data/data.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
