# Outpatient: Acute Respiratory Infection (ARI) Screening

Synthetic health survey package (fake data).

- form/outpatient_ari_visit.xlsx  (XLSForm for Kobo/ODK)
- data/submissions.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
