# Nutrition: Child MUAC Screening and Referral (6–59 months)

Synthetic health survey package (fake data).

- form/nutrition_muac_screening.xlsx  (XLSForm for Kobo/ODK)
- data/data.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
