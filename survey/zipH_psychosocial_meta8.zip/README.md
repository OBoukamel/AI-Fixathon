# Community Health: Psychosocial Distress Screening (brief)

Synthetic health survey package (fake data).

- form/psychosocial_screening.xlsx  (XLSForm for Kobo/ODK)
- data/SUBMISSIONS_export.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
