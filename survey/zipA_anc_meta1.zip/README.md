# Maternal Health: Antenatal Care (ANC) Visit

Synthetic health survey package (fake data).

- form/mh_anc_visit.xlsx  (XLSForm for Kobo/ODK)
- data/records.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
