# Malaria Case Management: RDT and Treatment

Synthetic health survey package (fake data).

- form/malaria_case_mgmt.xlsx  (XLSForm for Kobo/ODK)
- data/records.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
