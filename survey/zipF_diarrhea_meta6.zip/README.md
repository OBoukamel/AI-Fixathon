# Child Health: Diarrhea Episode + WASH Access

Synthetic health survey package (fake data).

- form/diarrhea_wash_episode.xlsx  (XLSForm for Kobo/ODK)
- data/data.csv     (synthetic submissions)
- meta/                (heterogeneous metadata formats)
